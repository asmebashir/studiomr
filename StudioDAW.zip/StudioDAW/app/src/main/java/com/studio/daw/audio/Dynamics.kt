package com.studio.daw.audio

import kotlin.math.*

private const val DB_PER_LN = 8.685889f
private const val LN_PER_DB = 0.11512925f
fun dbToLin(db: Float): Float = exp(db * LN_PER_DB)
fun linToDb(x: Float): Float = DB_PER_LN * ln(max(x, 1e-9f))

/** Feed-forward compressor with soft knee, smoothed in the gain-reduction domain. */
class Compressor(private val fs: Int) {
    var thresholdDb = -18f
    var ratio = 3f
    var kneeDb = 6f
    var makeupDb = 3f
    private var atk = 0f
    private var rel = 0f
    private var grSmooth = 0f
    @Volatile var gainReductionDb = 0f

    fun setTimes(attackMs: Float, releaseMs: Float) {
        atk = exp(-1f / (attackMs * 0.001f * fs))
        rel = exp(-1f / (releaseMs * 0.001f * fs))
    }

    fun process(x: Float): Float {
        val lvl = linToDb(abs(x))
        val over = lvl - thresholdDb
        val outLvl = when {
            2 * over < -kneeDb -> lvl
            2 * abs(over) <= kneeDb -> lvl + (1f / ratio - 1f) * (over + kneeDb / 2).pow(2) / (2 * kneeDb)
            else -> thresholdDb + over / ratio
        }
        val gr = max(lvl - outLvl, 0f)
        val c = if (gr > grSmooth) atk else rel
        grSmooth = c * grSmooth + (1 - c) * gr
        gainReductionDb = grSmooth
        return x * dbToLin(makeupDb - grSmooth)
    }
}

/** Gentle downward expander: lowers room noise between phrases without chopping tails. */
class NoiseGate(private val fs: Int) {
    var thresholdDb = -52f
    var floorDb = -20f
    private val atk = exp(-1f / (0.002f * fs))
    private val rel = exp(-1f / (0.15f * fs))
    private val holdMax = (0.05f * fs).toInt()
    private var env = 0f
    private var gain = 1f
    private var hold = 0

    fun process(x: Float): Float {
        val a = abs(x)
        env = if (a > env) a else env * 0.9995f
        val open = linToDb(env) > thresholdDb
        if (open) hold = holdMax else if (hold > 0) hold--
        val target = if (open || hold > 0) 1f else dbToLin(floorDb)
        val c = if (target > gain) atk else rel
        gain = c * gain + (1 - c) * target
        return x * gain
    }
}

/** Sidechain ducker: vocal level -> backing-track gain. */
class Ducker(private val fs: Int) {
    var thresholdDb = -38f
    var amountDb = 8f
    private val detAtk = exp(-1f / (0.005f * fs))
    private val detRel = exp(-1f / (0.05f * fs))
    private val gAtk = exp(-1f / (0.015f * fs))
    private val gRel = exp(-1f / (0.35f * fs))
    private var env = 0f
    private var gainDb = 0f

    /** Returns linear gain to apply to the backing track. */
    fun process(vocal: Float): Float {
        val a = abs(vocal)
        env = if (a > env) detAtk * env + (1 - detAtk) * a else detRel * env + (1 - detRel) * a
        val t = ((linToDb(env) - thresholdDb) / 6f).coerceIn(0f, 1f)
        val target = -amountDb * t
        val c = if (target < gainDb) gAtk else gRel
        gainDb = c * gainDb + (1 - c) * target
        return dbToLin(gainDb)
    }
}

/** Linked peak limiter (instant attack, smooth release) at -1 dBFS. */
class Limiter(fs: Int) {
    private val ceiling = 0.891f
    private val rel = exp(-1f / (0.08f * fs))
    private var g = 1f

    fun gainFor(peak: Float): Float {
        val need = if (peak > ceiling) ceiling / peak else 1f
        g = if (need < g) need else min(need, g + (1f - g) * (1f - rel))
        return g
    }
}
