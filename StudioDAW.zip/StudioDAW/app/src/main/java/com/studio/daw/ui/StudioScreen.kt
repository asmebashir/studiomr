package com.studio.daw.ui

import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.studio.daw.StudioViewModel
import com.studio.daw.audio.*

private val TABS = listOf("Clean", "EQ", "Dynamics", "Space", "Tune & Duck", "Mix")
private val KEYS = listOf("C", "C#", "D", "D#", "E", "F", "F#", "G", "G#", "A", "A#", "B")

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun StudioScreen(vm: StudioViewModel) {
    val p by vm.params.collectAsState()
    var tab by remember { mutableIntStateOf(0) }
    var inDb by remember { mutableFloatStateOf(-60f) }
    var outDb by remember { mutableFloatStateOf(-60f) }
    var gr by remember { mutableFloatStateOf(0f) }

    LaunchedEffect(Unit) {
        while (true) {
            withFrameNanos { }
            inDb = linToDb(vm.engine.processor.inputPeak)
            outDb = linToDb(vm.engine.processor.outputPeak)
            gr = vm.engine.processor.gainReductionDb
        }
    }

    val pickAudio = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { u: Uri? -> u?.let(vm::loadBacking) }
    val pickModel = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { u: Uri? -> u?.let(vm::runAi) }

    Column(
        Modifier.fillMaxSize().background(C.Bg).statusBarsPadding().navigationBarsPadding()
            .verticalScroll(rememberScrollState()).padding(12.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("STUDIO DAW", color = C.Gold, fontSize = 20.sp, fontWeight = FontWeight.Bold, letterSpacing = 3.sp)
            Spacer(Modifier.weight(1f))
            Text(vm.status, color = C.Dim, fontSize = 11.sp, maxLines = 2, modifier = Modifier.widthIn(max = 200.dp))
        }

        Visualizer(vm.engine)

        Column(Modifier.clip(RoundedCornerShape(12.dp)).background(C.Panel).padding(10.dp)) {
            LevelMeter(inDb, "IN")
            Spacer(Modifier.height(4.dp))
            LevelMeter(outDb, "OUT")
            Spacer(Modifier.height(4.dp))
            LevelMeter(-gr * 3f, "GR", color = C.Gold)
        }

        // Transport
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly, verticalAlignment = Alignment.CenterVertically) {
            OutlinedButton(onClick = vm::toggleMonitor) { Text(if (vm.running) "Stop" else "Rehearse") }
            RecordButton(vm.recording, onClick = vm::toggleRecord)
            OutlinedButton(onClick = { pickAudio.launch(arrayOf("audio/*")) }, enabled = !vm.busy) { Text("Backing") }
        }
        vm.backingName?.let { Text("♪ $it", color = C.Cyan, fontSize = 12.sp) }

        // Presets
        Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Presets.all.forEach { (name, preset) ->
                AssistChip(onClick = { vm.update { preset } }, label = { Text(name) })
            }
        }

        ScrollableTabRow(selectedTabIndex = tab, containerColor = C.Bg, contentColor = C.Gold, edgePadding = 0.dp) {
            TABS.forEachIndexed { i, t -> Tab(selected = tab == i, onClick = { tab = i }, text = { Text(t, fontSize = 13.sp) }) }
        }

        Column(Modifier.fillMaxWidth().clip(RoundedCornerShape(16.dp)).background(C.Panel).padding(12.dp)) {
            when (tab) {
                0 -> Clean(p, vm)
                1 -> Eq(p, vm)
                2 -> Dynamics(p, vm)
                3 -> Space(p, vm)
                4 -> TuneDuck(p, vm)
                5 -> Mix(p, vm)
            }
        }

        OutlinedButton(
            onClick = { pickModel.launch(arrayOf("*/*")) }, enabled = !vm.busy,
            modifier = Modifier.fillMaxWidth()
        ) { Text("AI Vocal Isolation (ONNX model) on last take") }
        Spacer(Modifier.height(24.dp))
    }
}

@Composable
private fun RecordButton(recording: Boolean, onClick: () -> Unit) {
    Box(
        Modifier.size(76.dp).clip(CircleShape).background(C.PanelHi).clickable(onClick = onClick),
        contentAlignment = Alignment.Center
    ) {
        Canvas(Modifier.size(52.dp)) {
            if (recording) drawRoundRect(C.Red, Offset(size.width * 0.18f, size.height * 0.18f),
                androidx.compose.ui.geometry.Size(size.width * 0.64f, size.height * 0.64f),
                androidx.compose.ui.geometry.CornerRadius(10f))
            else drawCircle(C.Red)
        }
    }
}

@Composable private fun KnobRow(content: @Composable RowScope.() -> Unit) =
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly, content = content)

@Composable
private fun Clean(p: FxParams, vm: StudioViewModel) {
    KnobRow {
        Knob("HPF", p.hpfHz, 20f..300f, " Hz", 0) { v -> vm.update { it.copy(hpfHz = v) } }
        Knob("LPF", p.lpfHz, 6000f..20000f, " Hz", 0) { v -> vm.update { it.copy(lpfHz = v) } }
        Knob("Gate", p.gateThresholdDb, -80f..-20f, " dB", 0) { v -> vm.update { it.copy(gateThresholdDb = v) } }
    }
    SwitchRow("Noise gate", p.gateEnabled) { v -> vm.update { it.copy(gateEnabled = v) } }
}

@Composable
private fun Eq(p: FxParams, vm: StudioViewModel) {
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly) {
        for (i in 0 until 5) {
            Fader(EqBands.names[i] + "\n" + EqBands.labels[i], p.eqGainsDb[i], -12f..12f) { v ->
                vm.update { s -> s.copy(eqGainsDb = s.eqGainsDb.toMutableList().also { it[i] = v }) }
            }
        }
    }
}

@Composable
private fun Dynamics(p: FxParams, vm: StudioViewModel) {
    KnobRow {
        Knob("Thresh", p.compThresholdDb, -40f..0f, " dB", 0) { v -> vm.update { it.copy(compThresholdDb = v) } }
        Knob("Ratio", p.compRatio, 1f..10f, ":1") { v -> vm.update { it.copy(compRatio = v) } }
        Knob("Makeup", p.compMakeupDb, 0f..12f, " dB") { v -> vm.update { it.copy(compMakeupDb = v) } }
    }
    KnobRow {
        Knob("Attack", p.compAttackMs, 1f..50f, " ms", 0) { v -> vm.update { it.copy(compAttackMs = v) } }
        Knob("Release", p.compReleaseMs, 20f..500f, " ms", 0) { v -> vm.update { it.copy(compReleaseMs = v) } }
    }
}

@Composable
private fun Space(p: FxParams, vm: StudioViewModel) {
    Text("Reverb", color = C.Gold, fontSize = 12.sp)
    KnobRow {
        Knob("Mix", p.reverbMix, 0f..0.5f, "", 2) { v -> vm.update { it.copy(reverbMix = v) } }
        Knob("Room", p.reverbRoom, 0f..1f, "", 2) { v -> vm.update { it.copy(reverbRoom = v) } }
        Knob("Damp", p.reverbDamp, 0f..0.95f, "", 2) { v -> vm.update { it.copy(reverbDamp = v) } }
    }
    Text("Delay", color = C.Gold, fontSize = 12.sp)
    KnobRow {
        Knob("Time", p.delayMs, 60f..600f, " ms", 0) { v -> vm.update { it.copy(delayMs = v) } }
        Knob("Feedback", p.delayFeedback, 0f..0.7f, "", 2) { v -> vm.update { it.copy(delayFeedback = v) } }
        Knob("Mix", p.delayMix, 0f..0.4f, "", 2) { v -> vm.update { it.copy(delayMix = v) } }
    }
}

@Composable
private fun TuneDuck(p: FxParams, vm: StudioViewModel) {
    SwitchRow("Auto-Pitch", p.pitchEnabled) { v -> vm.update { it.copy(pitchEnabled = v) } }
    Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
        KEYS.forEachIndexed { i, k ->
            FilterChip(selected = p.pitchKey == i, onClick = { vm.update { it.copy(pitchKey = i) } }, label = { Text(k) })
        }
    }
    Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
        ScaleType.values().forEach { s ->
            FilterChip(selected = p.pitchScale == s, onClick = { vm.update { it.copy(pitchScale = s) } }, label = { Text(s.label) })
        }
    }
    KnobRow {
        Knob("Strength", p.pitchStrength, 0f..1f, "", 2) { v -> vm.update { it.copy(pitchStrength = v) } }
        Knob("Retune", p.pitchRetuneMs, 5f..200f, " ms", 0) { v -> vm.update { it.copy(pitchRetuneMs = v) } }
    }
    HorizontalDivider(Modifier.padding(vertical = 8.dp), color = C.Track)
    SwitchRow("Auto-Ducking (backing)", p.duckEnabled) { v -> vm.update { it.copy(duckEnabled = v) } }
    KnobRow {
        Knob("Depth", p.duckAmountDb, 0f..20f, " dB") { v -> vm.update { it.copy(duckAmountDb = v) } }
        Knob("Thresh", p.duckThresholdDb, -60f..-15f, " dB", 0) { v -> vm.update { it.copy(duckThresholdDb = v) } }
    }
}

@Composable
private fun Mix(p: FxParams, vm: StudioViewModel) {
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly) {
        Fader("Vocal", p.vocalGainDb, -12f..12f) { v -> vm.update { it.copy(vocalGainDb = v) } }
        Fader("Backing", p.backingGainDb, -24f..6f) { v -> vm.update { it.copy(backingGainDb = v) } }
        Fader("Master", p.masterDb, -12f..6f) { v -> vm.update { it.copy(masterDb = v) } }
    }
}

@Composable
private fun SwitchRow(label: String, on: Boolean, onChange: (Boolean) -> Unit) {
    Row(Modifier.fillMaxWidth().padding(vertical = 4.dp), verticalAlignment = Alignment.CenterVertically) {
        Text(label, color = C.Text, modifier = Modifier.weight(1f))
        Switch(checked = on, onCheckedChange = onChange)
    }
}
