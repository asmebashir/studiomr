package com.studio.daw.ui

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

object C {
    val Bg = Color(0xFF0B0D12)
    val Panel = Color(0xFF141821)
    val PanelHi = Color(0xFF1B2130)
    val Track = Color(0xFF2A2F3A)
    val Gold = Color(0xFFE8B84A)
    val Cyan = Color(0xFF37D5D6)
    val Red = Color(0xFFFF4D4D)
    val Text = Color(0xFFE9ECF2)
    val Dim = Color(0xFF8A93A6)
}

@Composable
fun StudioTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = darkColorScheme(
            primary = C.Gold, secondary = C.Cyan, background = C.Bg,
            surface = C.Panel, onSurface = C.Text, onBackground = C.Text, onPrimary = Color.Black
        ),
        content = content
    )
}
