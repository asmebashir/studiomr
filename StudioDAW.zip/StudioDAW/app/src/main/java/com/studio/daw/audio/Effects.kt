package com.studio.daw.audio

import kotlin.math.max

/** Freeverb-style reverb (8 combs + 4 all-passes), mono in / mono out. */
class Reverb(fs: Int) {
    private class Comb(size: Int) {
        val buf = FloatArray(size); var idx = 0; var store = 0f
        fun process(inp: Float, fb: Float, damp: Float): Float {
            val out = buf[idx]
            store = out * (1 - damp) + store * damp
            buf[idx] = inp + store * fb
            if (++idx >= buf.size) idx = 0
            return out
        }
    }

    private class AllPass(size: Int) {
        val buf = FloatArray(size); var idx = 0
        fun process(inp: Float): Float {
            val b = buf[idx]
            val out = -inp + b
            buf[idx] = inp + b * 0.5f
            if (++idx >= buf.size) idx = 0
            return out
        }
    }

    private val scale = fs / 44100f
    private val combs = intArrayOf(1116, 1188, 1277, 1356, 1422, 1491, 1557, 1617)
        .map { Comb((it * scale).toInt()) }
    private val allpasses = intArrayOf(556, 441, 341, 225).map { AllPass((it * scale).toInt()) }
    private var feedback = 0.84f
    private var damp = 0.5f

    fun set(room: Float, damping: Float) {
        feedback = room.coerceIn(0f, 1f) * 0.28f + 0.7f
        damp = damping.coerceIn(0f, 0.95f)
    }

    fun process(x: Float): Float {
        val inp = x * 0.015f
        var sum = 0f
        for (c in combs) sum += c.process(inp, feedback, damp)
        for (a in allpasses) sum = a.process(sum)
        return sum * 3f
    }
}

/** Feedback delay with a darkened repeat path and click-free time changes. */
class Delay(private val fs: Int) {
    private val buf = FloatArray(fs * 2)
    private var w = 0
    private var cur = fs * 0.28f
    private var target = cur
    private var lp = 0f
    var feedback = 0.25f

    fun setTimeMs(ms: Float) { target = (ms * 0.001f * fs).coerceIn(32f, buf.size - 4f) }

    fun process(x: Float): Float {
        cur += (target - cur) * 0.0005f
        var rp = w - cur
        if (rp < 0) rp += buf.size
        val i0 = rp.toInt() % buf.size
        val i1 = (i0 + 1) % buf.size
        val fr = rp - rp.toInt()
        val out = buf[i0] * (1 - fr) + buf[i1] * fr
        lp += 0.45f * (out - lp)
        buf[w] = x + lp * feedback
        if (++w >= buf.size) w = 0
        return out
    }
}
