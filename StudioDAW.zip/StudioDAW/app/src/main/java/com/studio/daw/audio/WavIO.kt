package com.studio.daw.audio

import java.io.File
import java.io.RandomAccessFile
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.util.concurrent.LinkedBlockingQueue
import java.util.concurrent.TimeUnit

/** Background-threaded 16-bit PCM WAV writer, so the audio thread never touches the disk. */
class WavWriter(file: File, private val sampleRate: Int, private val channels: Int) {
    private val raf = RandomAccessFile(file, "rw")
    private val queue = LinkedBlockingQueue<ShortArray>()
    @Volatile private var closing = false
    private var bytes = 0L

    private val worker = Thread {
        while (true) {
            val blk = queue.poll(100, TimeUnit.MILLISECONDS)
            if (blk == null) { if (closing) break else continue }
            val bb = ByteBuffer.allocate(blk.size * 2).order(ByteOrder.LITTLE_ENDIAN)
            bb.asShortBuffer().put(blk)
            raf.write(bb.array())
            bytes += blk.size * 2L
        }
    }

    init {
        raf.setLength(0)
        raf.write(ByteArray(44))
        worker.start()
    }

    fun write(interleaved: FloatArray, count: Int) {
        val s = ShortArray(count) { (interleaved[it].coerceIn(-1f, 1f) * 32767f).toInt().toShort() }
        queue.offer(s)
    }

    fun close() {
        closing = true
        worker.join()
        val h = ByteBuffer.allocate(44).order(ByteOrder.LITTLE_ENDIAN)
        h.put("RIFF".toByteArray()); h.putInt((36 + bytes).toInt())
        h.put("WAVE".toByteArray()); h.put("fmt ".toByteArray()); h.putInt(16)
        h.putShort(1); h.putShort(channels.toShort()); h.putInt(sampleRate)
        h.putInt(sampleRate * channels * 2); h.putShort((channels * 2).toShort()); h.putShort(16)
        h.put("data".toByteArray()); h.putInt(bytes.toInt())
        raf.seek(0); raf.write(h.array()); raf.close()
    }
}

object WavIO {
    /** Reads a mono 16-bit WAV written by [WavWriter] (canonical 44-byte header). */
    fun readMono16(file: File): FloatArray {
        val all = file.readBytes()
        val bb = ByteBuffer.wrap(all, 44, all.size - 44).order(ByteOrder.LITTLE_ENDIAN)
        val n = (all.size - 44) / 2
        return FloatArray(n) { bb.short / 32768f }
    }

    fun writeMono16(file: File, data: FloatArray, sampleRate: Int) {
        val w = WavWriter(file, sampleRate, 1)
        var i = 0
        while (i < data.size) {
            val c = minOf(4096, data.size - i)
            w.write(data.copyOfRange(i, i + c), c)
            i += c
        }
        w.close()
    }
}
