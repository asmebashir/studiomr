package com.studio.daw.ui

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.gestures.detectVerticalDragGestures
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import java.util.Locale
import kotlin.math.cos
import kotlin.math.sin

fun fmt(v: Float, digits: Int = 1): String = String.format(Locale.US, "%.${digits}f", v)

/** Rotary knob: drag up/down. */
@Composable
fun Knob(
    label: String, value: Float, range: ClosedFloatingPointRange<Float>, unit: String = "",
    digits: Int = 1, modifier: Modifier = Modifier, onChange: (Float) -> Unit
) {
    val v by rememberUpdatedState(value)
    val cb by rememberUpdatedState(onChange)
    val span = range.endInclusive - range.start
    Column(modifier.padding(6.dp), horizontalAlignment = Alignment.CenterHorizontally) {
        Canvas(
            Modifier.size(66.dp).pointerInput(range) {
                detectVerticalDragGestures { change, dy ->
                    change.consume()
                    cb((v - dy / 320f * span).coerceIn(range.start, range.endInclusive))
                }
            }
        ) {
            val stroke = 7.dp.toPx()
            val inset = stroke / 2 + 2.dp.toPx()
            val tl = Offset(inset, inset)
            val sz = Size(size.width - 2 * inset, size.height - 2 * inset)
            drawArc(C.Track, 135f, 270f, false, tl, sz, style = Stroke(stroke, cap = StrokeCap.Round))
            val frac = ((v - range.start) / span).coerceIn(0f, 1f)
            drawArc(C.Gold, 135f, 270f * frac, false, tl, sz, style = Stroke(stroke, cap = StrokeCap.Round))
            val ang = Math.toRadians((135 + 270 * frac).toDouble())
            val r = size.width / 2 - inset - stroke
            val dir = Offset(cos(ang).toFloat(), sin(ang).toFloat())
            drawLine(Color.White, center + dir * (r * 0.3f), center + dir * r, 3.dp.toPx(), StrokeCap.Round)
        }
        Text(label, color = C.Dim, fontSize = 11.sp)
        Text(fmt(value, digits) + unit, color = C.Text, fontSize = 12.sp)
    }
}

/** Vertical fader. */
@Composable
fun Fader(
    label: String, value: Float, range: ClosedFloatingPointRange<Float>, unit: String = " dB",
    modifier: Modifier = Modifier, height: androidx.compose.ui.unit.Dp = 150.dp, onChange: (Float) -> Unit
) {
    val cb by rememberUpdatedState(onChange)
    val span = range.endInclusive - range.start
    val v by rememberUpdatedState(value)
    Column(modifier.padding(horizontal = 4.dp), horizontalAlignment = Alignment.CenterHorizontally) {
        Text(fmt(value) + unit, color = C.Text, fontSize = 11.sp)
        Canvas(
            Modifier.width(44.dp).height(height).pointerInput(range) {
                val h = size.height.toFloat()
                fun set(y: Float) { cb(range.start + (1f - (y / h).coerceIn(0f, 1f)) * span) }
                detectVerticalDragGestures(onDragStart = { set(it.y) }) { c, _ -> c.consume(); set(c.position.y) }
            }
        ) {
            val cx = size.width / 2
            drawLine(C.Track, Offset(cx, 6f), Offset(cx, size.height - 6f), 6.dp.toPx(), StrokeCap.Round)
            val frac = ((v - range.start) / span).coerceIn(0f, 1f)
            val y = size.height - 6f - frac * (size.height - 12f)
            drawLine(C.Cyan, Offset(cx, size.height - 6f), Offset(cx, y), 6.dp.toPx(), StrokeCap.Round)
            drawRoundRect(
                C.Text, Offset(cx - 18.dp.toPx(), y - 7.dp.toPx()), Size(36.dp.toPx(), 14.dp.toPx()),
                androidx.compose.ui.geometry.CornerRadius(4.dp.toPx())
            )
            drawLine(C.Bg, Offset(cx - 12.dp.toPx(), y), Offset(cx + 12.dp.toPx(), y), 2.dp.toPx())
        }
        Text(label, color = C.Dim, fontSize = 11.sp)
    }
}

/** Horizontal level meter in dBFS (-60..0). */
@Composable
fun LevelMeter(db: Float, label: String, modifier: Modifier = Modifier, color: Color = C.Cyan) {
    Row(modifier, verticalAlignment = Alignment.CenterVertically) {
        Text(label, color = C.Dim, fontSize = 11.sp, modifier = Modifier.width(34.dp))
        Canvas(Modifier.weight(1f).height(8.dp)) {
            drawRoundRect(C.Track, size = size, cornerRadius = androidx.compose.ui.geometry.CornerRadius(4f))
            val f = ((db + 60f) / 60f).coerceIn(0f, 1f)
            drawRoundRect(
                if (db > -3f) C.Red else color, size = Size(size.width * f, size.height),
                cornerRadius = androidx.compose.ui.geometry.CornerRadius(4f)
            )
        }
    }
}
