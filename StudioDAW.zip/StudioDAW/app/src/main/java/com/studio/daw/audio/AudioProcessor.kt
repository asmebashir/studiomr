package com.studio.daw.audio

import kotlin.math.abs
import kotlin.math.max

/**
 * The full signal chain. Runs on the audio thread, allocation-free.
 *
 *  mic ─► gain ─► HPF(24dB/oct) ─► LPF ─► Gate ─► Auto-Pitch ─► 5-band EQ ─► Compressor ─┐
 *                                                                                         ├─► Reverb / Delay sends ─┐
 *  vocal (post-comp) ─► sidechain ─► Ducker ─► ×backing track ──────────────────────────┘                         │
 *                                                                                                                  ▼
 *                                             (vocal + FX) + (ducked backing) ─► master ─► Limiter ─► stereo out
 */
class AudioProcessor(private val fs: Int) {
    @Volatile var params = FxParams()
    private var applied: FxParams? = null

    private val hpf1 = Biquad(); private val hpf2 = Biquad()
    private val lpf = Biquad()
    private val gate = NoiseGate(fs)
    val pitch = PitchCorrector(fs)
    private val eq = ParametricEq(fs)
    private val comp = Compressor(fs)
    private val reverb = Reverb(fs)
    private val delay = Delay(fs)
    private val ducker = Ducker(fs)
    private val limiter = Limiter(fs)

    // Meters (read by UI)
    @Volatile var inputPeak = 0f
    @Volatile var outputPeak = 0f
    val gainReductionDb: Float get() = comp.gainReductionDb

    // Cached linear gains
    private var vGain = 1f; private var bGain = 1f; private var mGain = 1f

    private fun apply(p: FxParams) {
        hpf1.highPass(fs, p.hpfHz, 0.5412f)
        hpf2.highPass(fs, p.hpfHz, 1.3066f)
        lpf.lowPass(fs, p.lpfHz)
        gate.thresholdDb = p.gateThresholdDb
        eq.setGains(p.eqGainsDb)
        comp.thresholdDb = p.compThresholdDb
        comp.ratio = p.compRatio
        comp.makeupDb = p.compMakeupDb
        comp.setTimes(p.compAttackMs, p.compReleaseMs)
        reverb.set(p.reverbRoom, p.reverbDamp)
        delay.setTimeMs(p.delayMs)
        delay.feedback = p.delayFeedback
        pitch.keyRoot = p.pitchKey
        pitch.scale = p.pitchScale
        pitch.strength = p.pitchStrength
        pitch.setRetuneMs(p.pitchRetuneMs)
        ducker.thresholdDb = p.duckThresholdDb
        ducker.amountDb = p.duckAmountDb
        vGain = dbToLin(p.vocalGainDb)
        bGain = dbToLin(p.backingGainDb)
        mGain = dbToLin(p.masterDb)
    }

    /**
     * @param inp     mono mic samples (n)
     * @param backing interleaved stereo backing track (2n), already position-advanced by the engine
     * @param out     interleaved stereo output (2n)
     */
    fun processBlock(inp: FloatArray, backing: FloatArray, out: FloatArray, n: Int) {
        val p = params
        if (p !== applied) { apply(p); applied = p }

        var inPk = 0f
        var outPk = 0f
        for (i in 0 until n) {
            var x = inp[i] * vGain
            inPk = max(inPk, abs(x))

            x = hpf2.process(hpf1.process(x))
            x = lpf.process(x)
            if (p.gateEnabled) x = gate.process(x)
            if (p.pitchEnabled) x = pitch.process(x)
            x = eq.process(x)
            x = comp.process(x)

            val wet = reverb.process(x) * p.reverbMix + delay.process(x) * p.delayMix
            val vocal = x + wet

            val duck = if (p.duckEnabled) ducker.process(x) else 1f
            val bg = bGain * duck

            var l = (vocal + backing[2 * i] * bg) * mGain
            var r = (vocal + backing[2 * i + 1] * bg) * mGain

            val g = limiter.gainFor(max(abs(l), abs(r)))
            l *= g; r *= g
            out[2 * i] = l; out[2 * i + 1] = r
            outPk = max(outPk, max(abs(l), abs(r)))
        }
        inputPeak = inPk
        outputPeak = outPk
    }

    /** Dry-vocal-only render for offline use (e.g. re-processing a recorded take). */
    fun resetState() { applied = null }
}
