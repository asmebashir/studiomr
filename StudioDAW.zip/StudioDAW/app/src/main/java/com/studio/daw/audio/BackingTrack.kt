package com.studio.daw.audio

import android.content.Context
import android.media.MediaCodec
import android.media.MediaExtractor
import android.media.MediaFormat
import android.net.Uri
import java.nio.ByteOrder

/** Backing track held as 16-bit interleaved stereo at the engine sample rate (compact: ~11 MB/min). */
class BackingTrack(val pcm: ShortArray, val name: String, val sampleRate: Int) {
    val frames = pcm.size / 2
    @Volatile var pos = 0
    val durationSec get() = frames / sampleRate.toFloat()

    fun read(dst: FloatArray, n: Int) {
        var p = pos
        for (i in 0 until n) {
            if (p < frames) {
                dst[2 * i] = pcm[2 * p] / 32768f
                dst[2 * i + 1] = pcm[2 * p + 1] / 32768f
                p++
            } else { dst[2 * i] = 0f; dst[2 * i + 1] = 0f }
        }
        pos = p
    }
}

object BackingTrackLoader {
    private class ShortBuf {
        var a = ShortArray(1 shl 20); var n = 0
        fun add(src: java.nio.ShortBuffer) {
            val c = src.remaining()
            if (n + c > a.size) a = a.copyOf(maxOf(a.size * 2, n + c))
            src.get(a, n, c); n += c
        }
    }

    /** Decodes mp3/aac/wav/flac/ogg via MediaCodec, converts to stereo, resamples to [targetRate]. */
    fun load(context: Context, uri: Uri, name: String, targetRate: Int): BackingTrack {
        val ex = MediaExtractor()
        ex.setDataSource(context, uri, null)
        val idx = (0 until ex.trackCount).first {
            ex.getTrackFormat(it).getString(MediaFormat.KEY_MIME)?.startsWith("audio/") == true
        }
        ex.selectTrack(idx)
        val fmt = ex.getTrackFormat(idx)
        val codec = MediaCodec.createDecoderByType(fmt.getString(MediaFormat.KEY_MIME)!!)
        codec.configure(fmt, null, null, 0)
        codec.start()

        var sr = fmt.getInteger(MediaFormat.KEY_SAMPLE_RATE)
        var ch = fmt.getInteger(MediaFormat.KEY_CHANNEL_COUNT)
        val buf = ShortBuf()
        val info = MediaCodec.BufferInfo()
        var inDone = false
        var outDone = false
        while (!outDone) {
            if (!inDone) {
                val i = codec.dequeueInputBuffer(10_000)
                if (i >= 0) {
                    val ib = codec.getInputBuffer(i)!!
                    val sz = ex.readSampleData(ib, 0)
                    if (sz < 0) {
                        codec.queueInputBuffer(i, 0, 0, 0, MediaCodec.BUFFER_FLAG_END_OF_STREAM)
                        inDone = true
                    } else {
                        codec.queueInputBuffer(i, 0, sz, ex.sampleTime, 0)
                        ex.advance()
                    }
                }
            }
            val o = codec.dequeueOutputBuffer(info, 10_000)
            when {
                o >= 0 -> {
                    val ob = codec.getOutputBuffer(o)!!
                    ob.position(info.offset); ob.limit(info.offset + info.size)
                    buf.add(ob.order(ByteOrder.nativeOrder()).asShortBuffer())
                    codec.releaseOutputBuffer(o, false)
                    if (info.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM != 0) outDone = true
                }
                o == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED -> {
                    val f = codec.outputFormat
                    sr = f.getInteger(MediaFormat.KEY_SAMPLE_RATE)
                    ch = f.getInteger(MediaFormat.KEY_CHANNEL_COUNT)
                }
            }
        }
        codec.stop(); codec.release(); ex.release()

        // -> stereo + resample (linear)
        val srcFrames = buf.n / ch
        val step = sr.toDouble() / targetRate
        val outFrames = (srcFrames / step).toInt()
        val out = ShortArray(outFrames * 2)
        val a = buf.a
        for (i in 0 until outFrames) {
            val pos = i * step
            val i0 = pos.toInt().coerceAtMost(srcFrames - 1)
            val i1 = (i0 + 1).coerceAtMost(srcFrames - 1)
            val fr = (pos - i0).toFloat()
            for (c in 0..1) {
                val sc = if (ch == 1) 0 else c
                val s0 = a[i0 * ch + sc]; val s1 = a[i1 * ch + sc]
                out[2 * i + c] = (s0 + (s1 - s0) * fr).toInt().toShort()
            }
        }
        return BackingTrack(out, name, targetRate)
    }
}
