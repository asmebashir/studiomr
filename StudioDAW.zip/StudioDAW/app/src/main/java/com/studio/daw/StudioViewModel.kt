package com.studio.daw

import android.app.Application
import android.content.ContentValues
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.studio.daw.ai.VocalIsolator
import com.studio.daw.audio.*
import com.studio.daw.ui.fmt
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import java.io.File

class StudioViewModel(app: Application) : AndroidViewModel(app) {
    val engine = AudioEngine(app)

    private val _params = MutableStateFlow(FxParams())
    val params: StateFlow<FxParams> = _params.asStateFlow()

    var running by mutableStateOf(false); private set
    var recording by mutableStateOf(false); private set
    var busy by mutableStateOf(false); private set
    var backingName by mutableStateOf<String?>(null); private set
    var status by mutableStateOf("Ready — use wired headphones to avoid feedback")
        private set

    private var lastDry: File? = null

    fun update(f: (FxParams) -> FxParams) {
        val n = f(_params.value)
        _params.value = n
        engine.processor.params = n
    }

    fun toggleMonitor() {
        if (running) {
            if (recording) toggleRecord()
            engine.stop(); running = false; status = "Stopped"
        } else {
            engine.start(); running = true; status = "Monitoring (rehearsal)"
        }
    }

    fun toggleRecord() {
        val ctx = getApplication<Application>()
        if (!recording) {
            if (!running) { engine.start(); running = true }
            val dir = ctx.getExternalFilesDir(Environment.DIRECTORY_MUSIC)!!.apply { mkdirs() }
            val (_, dry) = engine.startRecording(dir)
            lastDry = dry
            recording = true; status = "Recording…"
        } else {
            engine.stopRecording(); recording = false
            status = "Saved to Music/StudioDAW"
            val dir = ctx.getExternalFilesDir(Environment.DIRECTORY_MUSIC)!!
            viewModelScope.launch(Dispatchers.IO) {
                dir.listFiles { f -> f.name.startsWith("take_") && f.name.endsWith("_mix.wav") }
                    ?.maxByOrNull { it.lastModified() }?.let { exportToMusic(it) }
            }
        }
    }

    fun loadBacking(uri: Uri) {
        val ctx = getApplication<Application>()
        busy = true; status = "Decoding backing track…"
        viewModelScope.launch(Dispatchers.Default) {
            try {
                val name = uri.lastPathSegment?.substringAfterLast('/') ?: "Backing track"
                val t = BackingTrackLoader.load(ctx, uri, name, AudioEngine.SR)
                engine.backing = t
                backingName = "${t.name} (${fmt(t.durationSec / 60f)} min)"
                status = "Backing track loaded"
            } catch (e: Exception) { status = "Could not decode file: ${e.message}" }
            busy = false
        }
    }

    /** Runs an ONNX model over the last dry take (offline) and saves *_ai.wav. */
    fun runAi(modelUri: Uri) {
        val dry = lastDry ?: run { status = "Record a take first"; return }
        val ctx = getApplication<Application>()
        busy = true; status = "AI cleanup running…"
        viewModelScope.launch(Dispatchers.Default) {
            try {
                val model = File(ctx.cacheDir, "model.onnx")
                ctx.contentResolver.openInputStream(modelUri)!!.use { i -> model.outputStream().use { i.copyTo(it) } }
                val clean = VocalIsolator(model.absolutePath).process(WavIO.readMono16(dry)) {
                    status = "AI cleanup ${(it * 100).toInt()}%"
                }
                val out = File(dry.parentFile, dry.name.replace("_dry", "_ai"))
                WavIO.writeMono16(out, clean, AudioEngine.SR)
                exportToMusic(out)
                status = "AI-cleaned vocal saved: ${out.name}"
            } catch (e: Throwable) { status = "AI failed: ${e.message}" }
            busy = false
        }
    }

    private fun exportToMusic(f: File) {
        if (Build.VERSION.SDK_INT < 29) return
        val res = getApplication<Application>().contentResolver
        val cv = ContentValues().apply {
            put(MediaStore.Audio.Media.DISPLAY_NAME, f.name)
            put(MediaStore.Audio.Media.MIME_TYPE, "audio/wav")
            put(MediaStore.Audio.Media.RELATIVE_PATH, "Music/StudioDAW")
        }
        val uri = res.insert(MediaStore.Audio.Media.EXTERNAL_CONTENT_URI, cv) ?: return
        res.openOutputStream(uri)?.use { o -> f.inputStream().use { it.copyTo(o) } }
    }

    override fun onCleared() { engine.stop() }
}
