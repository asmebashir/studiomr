package com.studio.daw.audio

import kotlin.math.*

/** 2048-pt FFT -> 32 log-spaced bands, plus a rolling peak waveform. Written by the audio thread, read by the UI. */
class SpectrumAnalyzer(private val fs: Int) {
    companion object { const val N = 2048; const val BANDS = 32; const val WAVE = 240 }

    private val ring = FloatArray(N)
    private var wr = 0
    private var since = 0
    private val re = FloatArray(N)
    private val im = FloatArray(N)
    private val win = FloatArray(N) { (0.5 - 0.5 * cos(2.0 * PI * it / (N - 1))).toFloat() }
    private val bands = FloatArray(BANDS)
    private val wave = FloatArray(WAVE)
    private var wavePos = 0
    private val edges = IntArray(BANDS + 1) {
        val f = 40.0 * (16000.0 / 40.0).pow(it / BANDS.toDouble())
        (f * N / fs).roundToInt().coerceIn(1, N / 2 - 1)
    }

    fun pushStereo(buf: FloatArray, frames: Int) {
        var pk = 0f
        for (i in 0 until frames) {
            val m = 0.5f * (buf[2 * i] + buf[2 * i + 1])
            ring[wr] = m
            wr = (wr + 1) and (N - 1)
            pk = max(pk, abs(m))
            if (++since == 1024) { since = 0; compute() }
        }
        wave[wavePos] = pk
        wavePos = (wavePos + 1) % WAVE
    }

    private fun compute() {
        for (i in 0 until N) { re[i] = ring[(wr + i) and (N - 1)] * win[i]; im[i] = 0f }
        fft()
        for (b in 0 until BANDS) {
            val lo = edges[b]
            val hi = max(edges[b + 1], lo + 1)
            var m = 0f
            for (k in lo until hi) m = max(m, sqrt(re[k] * re[k] + im[k] * im[k]))
            val db = 20f * log10(m / (N / 4f) + 1e-9f)
            val v = ((db + 80f) / 80f).coerceIn(0f, 1f)
            bands[b] = if (v > bands[b]) v else bands[b] * 0.85f + v * 0.15f
        }
    }

    private fun fft() {
        var j = 0
        for (i in 1 until N) {
            var bit = N shr 1
            while ((j and bit) != 0) { j = j xor bit; bit = bit shr 1 }
            j = j xor bit
            if (i < j) {
                val tr = re[i]; re[i] = re[j]; re[j] = tr
                val ti = im[i]; im[i] = im[j]; im[j] = ti
            }
        }
        var len = 2
        while (len <= N) {
            val ang = -2.0 * PI / len
            val wr0 = cos(ang).toFloat(); val wi0 = sin(ang).toFloat()
            val half = len / 2
            var i = 0
            while (i < N) {
                var cr = 1f; var ci = 0f
                for (k in 0 until half) {
                    val a = i + k; val b = a + half
                    val vr = re[b] * cr - im[b] * ci
                    val vi = re[b] * ci + im[b] * cr
                    re[b] = re[a] - vr; im[b] = im[a] - vi
                    re[a] += vr; im[a] += vi
                    val ncr = cr * wr0 - ci * wi0
                    ci = cr * wi0 + ci * wr0
                    cr = ncr
                }
                i += len
            }
            len = len shl 1
        }
    }

    fun snapshotBands(): FloatArray = bands.copyOf()

    fun snapshotWave(): FloatArray {
        val out = FloatArray(WAVE)
        val p = wavePos
        for (i in 0 until WAVE) out[i] = wave[(p + i) % WAVE]
        return out
    }
}
