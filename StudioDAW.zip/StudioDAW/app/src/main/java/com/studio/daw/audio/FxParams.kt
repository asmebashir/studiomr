package com.studio.daw.audio

enum class ScaleType(val label: String, val intervals: IntArray) {
    CHROMATIC("Chromatic", IntArray(12) { it }),
    MAJOR("Major", intArrayOf(0, 2, 4, 5, 7, 9, 11)),
    MINOR("Minor", intArrayOf(0, 2, 3, 5, 7, 8, 10))
}

/** Immutable snapshot of every knob. The UI swaps the whole object; the audio thread picks it up at block start. */
data class FxParams(
    // Levels
    val vocalGainDb: Float = 0f,
    val backingGainDb: Float = -3f,
    val masterDb: Float = 0f,
    // Cleanup
    val hpfHz: Float = 90f,
    val lpfHz: Float = 16000f,
    val gateEnabled: Boolean = true,
    val gateThresholdDb: Float = -52f,
    // 5-band EQ gains (dB): Low shelf 100, Warmth 250, Body 1k, Presence 3.5k, Air shelf 10k
    val eqGainsDb: List<Float> = listOf(0f, 1.5f, 0f, 2.5f, 2f),
    // Compressor
    val compThresholdDb: Float = -18f,
    val compRatio: Float = 3f,
    val compAttackMs: Float = 8f,
    val compReleaseMs: Float = 120f,
    val compMakeupDb: Float = 3f,
    // Reverb / Delay
    val reverbMix: Float = 0.15f,
    val reverbRoom: Float = 0.6f,
    val reverbDamp: Float = 0.5f,
    val delayMs: Float = 280f,
    val delayFeedback: Float = 0.25f,
    val delayMix: Float = 0.08f,
    // Auto-pitch
    val pitchEnabled: Boolean = false,
    val pitchKey: Int = 0,               // 0 = C ... 11 = B
    val pitchScale: ScaleType = ScaleType.CHROMATIC,
    val pitchStrength: Float = 0.8f,     // 0..1
    val pitchRetuneMs: Float = 40f,      // lower = more "robotic"
    // Auto-ducking of the backing track
    val duckEnabled: Boolean = true,
    val duckAmountDb: Float = 8f,
    val duckThresholdDb: Float = -38f
)

object Presets {
    val all: List<Pair<String, FxParams>> = listOf(
        "Studio Vocal" to FxParams(),
        "Warm Radio" to FxParams(
            hpfHz = 110f, eqGainsDb = listOf(2f, 3f, -1f, 2f, 0f),
            compRatio = 4f, compMakeupDb = 4f, reverbMix = 0.06f, delayMix = 0f
        ),
        "Clean Speech" to FxParams(
            hpfHz = 100f, eqGainsDb = listOf(-2f, 0f, 0f, 3f, 1f),
            compThresholdDb = -20f, compRatio = 3.5f, reverbMix = 0f, delayMix = 0f
        ),
        "Big Chorus" to FxParams(
            eqGainsDb = listOf(1f, 1f, 0f, 3f, 3f), compRatio = 4f,
            reverbMix = 0.28f, reverbRoom = 0.8f, delayMix = 0.16f, delayFeedback = 0.35f
        )
    )
}
