package com.studio.daw.audio

import kotlin.math.*

/** RBJ-cookbook biquad (transposed direct form II). */
class Biquad {
    private var b0 = 1.0; private var b1 = 0.0; private var b2 = 0.0
    private var a1 = 0.0; private var a2 = 0.0
    private var z1 = 0.0; private var z2 = 0.0

    fun process(x: Float): Float {
        val xd = x.toDouble()
        val y = b0 * xd + z1
        z1 = b1 * xd - a1 * y + z2
        z2 = b2 * xd - a2 * y
        return y.toFloat()
    }

    private fun set(nb0: Double, nb1: Double, nb2: Double, a0: Double, na1: Double, na2: Double) {
        b0 = nb0 / a0; b1 = nb1 / a0; b2 = nb2 / a0; a1 = na1 / a0; a2 = na2 / a0
    }

    fun highPass(fs: Int, f: Float, q: Float = 0.7071f) {
        val w = 2.0 * PI * f / fs; val cs = cos(w); val al = sin(w) / (2.0 * q)
        set((1 + cs) / 2, -(1 + cs), (1 + cs) / 2, 1 + al, -2 * cs, 1 - al)
    }

    fun lowPass(fs: Int, f: Float, q: Float = 0.7071f) {
        val w = 2.0 * PI * f / fs; val cs = cos(w); val al = sin(w) / (2.0 * q)
        set((1 - cs) / 2, 1 - cs, (1 - cs) / 2, 1 + al, -2 * cs, 1 - al)
    }

    fun peaking(fs: Int, f: Float, q: Float, gainDb: Float) {
        val a = 10.0.pow(gainDb / 40.0)
        val w = 2.0 * PI * f / fs; val cs = cos(w); val al = sin(w) / (2.0 * q)
        set(1 + al * a, -2 * cs, 1 - al * a, 1 + al / a, -2 * cs, 1 - al / a)
    }

    fun lowShelf(fs: Int, f: Float, gainDb: Float) {
        val a = 10.0.pow(gainDb / 40.0)
        val w = 2.0 * PI * f / fs; val cs = cos(w)
        val al = sin(w) / 2.0 * sqrt(2.0)
        val t = 2 * sqrt(a) * al
        set(
            a * ((a + 1) - (a - 1) * cs + t),
            2 * a * ((a - 1) - (a + 1) * cs),
            a * ((a + 1) - (a - 1) * cs - t),
            (a + 1) + (a - 1) * cs + t,
            -2 * ((a - 1) + (a + 1) * cs),
            (a + 1) + (a - 1) * cs - t
        )
    }

    fun highShelf(fs: Int, f: Float, gainDb: Float) {
        val a = 10.0.pow(gainDb / 40.0)
        val w = 2.0 * PI * f / fs; val cs = cos(w)
        val al = sin(w) / 2.0 * sqrt(2.0)
        val t = 2 * sqrt(a) * al
        set(
            a * ((a + 1) + (a - 1) * cs + t),
            -2 * a * ((a - 1) + (a + 1) * cs),
            a * ((a + 1) + (a - 1) * cs - t),
            (a + 1) - (a - 1) * cs + t,
            2 * ((a - 1) - (a + 1) * cs),
            (a + 1) - (a - 1) * cs - t
        )
    }
}

object EqBands {
    val freqs = floatArrayOf(100f, 250f, 1000f, 3500f, 10000f)
    val qs = floatArrayOf(0.7f, 0.9f, 1.0f, 1.2f, 0.7f)
    val names = listOf("Low", "Warmth", "Body", "Presence", "Air")
    val labels = listOf("100 Hz", "250 Hz", "1 kHz", "3.5 kHz", "10 kHz")
}

/** 5-band parametric EQ: low shelf, three peaking bands, high shelf. */
class ParametricEq(private val fs: Int) {
    private val bands = Array(5) { Biquad() }
    private val active = BooleanArray(5)

    fun setGains(g: List<Float>) {
        for (i in 0 until 5) {
            val gain = g.getOrElse(i) { 0f }
            active[i] = abs(gain) > 0.05f
            if (!active[i]) continue
            when (i) {
                0 -> bands[i].lowShelf(fs, EqBands.freqs[i], gain)
                4 -> bands[i].highShelf(fs, EqBands.freqs[i], gain)
                else -> bands[i].peaking(fs, EqBands.freqs[i], EqBands.qs[i], gain)
            }
        }
    }

    fun process(x: Float): Float {
        var y = x
        for (i in 0 until 5) if (active[i]) y = bands[i].process(y)
        return y
    }
}
