package com.studio.daw.ui

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.unit.dp
import com.studio.daw.audio.AudioEngine
import com.studio.daw.audio.SpectrumAnalyzer

@Composable
fun Visualizer(engine: AudioEngine, modifier: Modifier = Modifier) {
    var bands by remember { mutableStateOf(FloatArray(SpectrumAnalyzer.BANDS)) }
    var wave by remember { mutableStateOf(FloatArray(SpectrumAnalyzer.WAVE)) }
    LaunchedEffect(engine) {
        while (true) {
            withFrameNanos { }
            bands = engine.analyzer.snapshotBands()
            wave = engine.analyzer.snapshotWave()
        }
    }
    Column(modifier.clip(RoundedCornerShape(16.dp)).background(C.Panel).padding(10.dp)) {
        Canvas(Modifier.fillMaxWidth().height(110.dp)) {
            val n = bands.size
            val gap = 3.dp.toPx()
            val bw = (size.width - gap * (n - 1)) / n
            val brush = Brush.verticalGradient(listOf(C.Gold, C.Cyan))
            for (i in 0 until n) {
                val h = (bands[i] * size.height).coerceAtLeast(2f)
                drawRoundRect(
                    brush, Offset(i * (bw + gap), size.height - h), Size(bw, h), CornerRadius(bw / 3)
                )
            }
        }
        Spacer(Modifier.height(8.dp))
        Canvas(Modifier.fillMaxWidth().height(44.dp)) {
            val n = wave.size
            val step = size.width / n
            val mid = size.height / 2
            for (i in 0 until n) {
                val h = (wave[i].coerceIn(0f, 1f) * mid * 1.6f).coerceAtLeast(1f)
                drawLine(C.Cyan, Offset(i * step, mid - h), Offset(i * step, mid + h), step * 0.6f, StrokeCap.Round)
            }
        }
    }
}
