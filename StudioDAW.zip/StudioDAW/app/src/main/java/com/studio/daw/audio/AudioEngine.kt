package com.studio.daw.audio

import android.content.Context
import android.media.*
import android.os.Process
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * Real-time I/O: AudioRecord (UNPROCESSED mic if available) -> AudioProcessor -> AudioTrack(LOW_LATENCY).
 * On modern devices PERFORMANCE_MODE_LOW_LATENCY routes through AAudio/MMAP, the same path Oboe uses.
 */
class AudioEngine(private val context: Context) {
    companion object { const val SR = 48_000; const val BLOCK = 256 }

    val processor = AudioProcessor(SR)
    val analyzer = SpectrumAnalyzer(SR)

    @Volatile var backing: BackingTrack? = null
    @Volatile var running = false
        private set
    @Volatile private var mixWriter: WavWriter? = null
    @Volatile private var dryWriter: WavWriter? = null
    private var thread: Thread? = null

    fun start() {
        if (running) return
        running = true
        thread = Thread({ loop() }, "audio-engine").also { it.priority = Thread.MAX_PRIORITY; it.start() }
    }

    fun stop() {
        running = false
        thread?.join(1500)
        thread = null
    }

    fun startRecording(dir: File): Pair<File, File> {
        val stamp = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date())
        val mix = File(dir, "take_${stamp}_mix.wav")
        val dry = File(dir, "take_${stamp}_dry.wav")
        backing?.pos = 0                      // restart the track so the take is aligned to it
        dryWriter = WavWriter(dry, SR, 1)
        mixWriter = WavWriter(mix, SR, 2)
        return mix to dry
    }

    fun stopRecording() {
        val m = mixWriter; val d = dryWriter
        mixWriter = null; dryWriter = null
        m?.close(); d?.close()
    }

    private fun loop() {
        Process.setThreadPriority(Process.THREAD_PRIORITY_URGENT_AUDIO)
        val am = context.getSystemService(Context.AUDIO_SERVICE) as AudioManager
        val unprocessed = am.getProperty(AudioManager.PROPERTY_SUPPORT_AUDIO_SOURCE_UNPROCESSED) == "true"
        val source = if (unprocessed) MediaRecorder.AudioSource.UNPROCESSED else MediaRecorder.AudioSource.MIC

        val inMin = AudioRecord.getMinBufferSize(SR, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_FLOAT)
        val rec = try {
            AudioRecord.Builder()
                .setAudioSource(source)
                .setAudioFormat(
                    AudioFormat.Builder().setEncoding(AudioFormat.ENCODING_PCM_FLOAT)
                        .setSampleRate(SR).setChannelMask(AudioFormat.CHANNEL_IN_MONO).build()
                )
                .setBufferSizeInBytes(maxOf(inMin, BLOCK * 4 * 2))
                .build()
        } catch (e: SecurityException) { running = false; return }

        val outMin = AudioTrack.getMinBufferSize(SR, AudioFormat.CHANNEL_OUT_STEREO, AudioFormat.ENCODING_PCM_FLOAT)
        val track = AudioTrack.Builder()
            .setAudioAttributes(
                AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_MEDIA)
                    .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC).build()
            )
            .setAudioFormat(
                AudioFormat.Builder().setEncoding(AudioFormat.ENCODING_PCM_FLOAT)
                    .setSampleRate(SR).setChannelMask(AudioFormat.CHANNEL_OUT_STEREO).build()
            )
            .setPerformanceMode(AudioTrack.PERFORMANCE_MODE_LOW_LATENCY)
            .setTransferMode(AudioTrack.MODE_STREAM)
            .setBufferSizeInBytes(maxOf(outMin, BLOCK * 2 * 4 * 2))
            .build()

        val inBuf = FloatArray(BLOCK)
        val backBuf = FloatArray(BLOCK * 2)
        val outBuf = FloatArray(BLOCK * 2)

        try {
            track.play()
            rec.startRecording()
            while (running) {
                var got = 0
                while (got < BLOCK && running) {
                    val r = rec.read(inBuf, got, BLOCK - got, AudioRecord.READ_BLOCKING)
                    if (r < 0) { running = false; break }
                    got += r
                }
                if (!running) break

                val bt = backing
                if (bt != null) bt.read(backBuf, BLOCK) else java.util.Arrays.fill(backBuf, 0f)

                processor.processBlock(inBuf, backBuf, outBuf, BLOCK)
                track.write(outBuf, 0, BLOCK * 2, AudioTrack.WRITE_BLOCKING)

                analyzer.pushStereo(outBuf, BLOCK)
                dryWriter?.write(inBuf, BLOCK)
                mixWriter?.write(outBuf, BLOCK * 2)
            }
        } finally {
            runCatching { rec.stop() }; rec.release()
            runCatching { track.stop() }; track.release()
            running = false
        }
    }
}
