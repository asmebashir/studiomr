package com.studio.daw.audio

import kotlin.math.*

/**
 * Real-time pitch correction:
 *  1) YIN pitch detection on a 4x-decimated signal (cheap),
 *  2) snap to the nearest note of the chosen key/scale,
 *  3) shift with a dual-tap crossfaded delay line.
 * Good for light "tightening"; hard-tune settings (retune < 20 ms, strength 1.0) give the T-Pain effect.
 */
class PitchCorrector(private val fs: Int) {
    var keyRoot = 0
    var scale = ScaleType.CHROMATIC
    var strength = 0.8f
    private var smoothC = 0.001f

    fun setRetuneMs(ms: Float) { smoothC = 1f - exp(-1f / (max(ms, 1f) * 0.001f * fs)) }

    @Volatile var detectedHz = 0f
    @Volatile var targetHz = 0f

    private val dec = 4
    private val fsD = fs / dec
    private val tauMin = (fsD / 1000f).toInt()
    private val tauMax = (fsD / 70f).toInt()
    private val w = 256
    private val ring = FloatArray(512)
    private var wr = 0
    private var decAcc = 0f
    private var decCnt = 0
    private var hop = 0
    private val frame = FloatArray(w + tauMax + 2)
    private val d = FloatArray(tauMax + 2)
    private val cm = FloatArray(tauMax + 2)

    private var targetRatio = 1f
    private var ratio = 1f
    private val shifter = PitchShifter(fs)

    init { setRetuneMs(40f) }

    fun process(x: Float): Float {
        decAcc += x
        if (++decCnt == dec) {
            ring[wr and 511] = decAcc / dec
            wr++; decAcc = 0f; decCnt = 0
            if (++hop >= 128) { hop = 0; analyze() }
        }
        ratio += (targetRatio - ratio) * smoothC
        return shifter.process(x, ratio)
    }

    private fun analyze() {
        val n = w + tauMax
        val start = wr - n
        var energy = 0f
        for (i in 0 until n) { val s = ring[(start + i) and 511]; frame[i] = s; energy += s * s }
        if (sqrt(energy / n) < 0.004f) { unvoiced(); return }

        var running = 0f
        cm[0] = 1f
        for (tau in 1..tauMax) {
            var sum = 0f
            for (j in 0 until w) { val df = frame[j] - frame[j + tau]; sum += df * df }
            d[tau] = sum
            running += sum
            cm[tau] = if (running > 0f) sum * tau / running else 1f
        }
        var tau = -1
        var t = tauMin
        while (t <= tauMax) {
            if (cm[t] < 0.15f) {
                while (t + 1 <= tauMax && cm[t + 1] < cm[t]) t++
                tau = t; break
            }
            t++
        }
        if (tau < 0) { unvoiced(); return }

        val x0 = cm[tau - 1]; val x1 = cm[tau]; val x2 = cm[min(tau + 1, tauMax)]
        val den = x0 - 2 * x1 + x2
        val shift = if (abs(den) > 1e-9f) 0.5f * (x0 - x2) / den else 0f
        val f0 = fsD / (tau + shift)
        if (f0 < 70f || f0 > 1000f) { unvoiced(); return }

        val midi = 69f + 12f * ln(f0 / 440f) / ln(2f)
        val target = snap(midi)
        detectedHz = f0
        targetHz = 440f * 2f.pow((target - 69f) / 12f)
        targetRatio = 2f.pow((target - midi) * strength / 12f).coerceIn(0.85f, 1.18f)
    }

    private fun unvoiced() { targetRatio = 1f; detectedHz = 0f; targetHz = 0f }

    private fun snap(midi: Float): Float {
        val ints = scale.intervals
        var best = midi
        var bestDist = Float.MAX_VALUE
        val lo = floor(midi).toInt() - 2
        val hi = ceil(midi).toInt() + 2
        for (n in lo..hi) {
            val pc = Math.floorMod(n - keyRoot, 12)
            if (ints.contains(pc)) {
                val dist = abs(n - midi)
                if (dist < bestDist) { bestDist = dist; best = n.toFloat() }
            }
        }
        return best
    }
}

/** Dual-tap delay-line pitch shifter with sin^2 crossfade (constant-gain). */
class PitchShifter(fs: Int) {
    private val win = (0.035f * fs).toInt()
    private val buf = FloatArray(win * 4)
    private var w = 0
    private var phase = 0f

    fun process(x: Float, ratio: Float): Float {
        buf[w] = x
        phase += (1f - ratio) / win
        if (phase >= 1f) phase -= 1f
        if (phase < 0f) phase += 1f
        val p2 = (phase + 0.5f) % 1f
        val y = tap(phase) * sq(sin(PI.toFloat() * phase)) + tap(p2) * sq(sin(PI.toFloat() * p2))
        if (++w >= buf.size) w = 0
        return y
    }

    private fun sq(v: Float) = v * v

    private fun tap(p: Float): Float {
        var rp = w - p * win
        while (rp < 0) rp += buf.size
        val i0 = rp.toInt() % buf.size
        val i1 = (i0 + 1) % buf.size
        val fr = rp - floor(rp)
        return buf[i0] * (1 - fr) + buf[i1] * fr
    }
}
