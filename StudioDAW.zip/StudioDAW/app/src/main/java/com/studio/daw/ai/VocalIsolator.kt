package com.studio.daw.ai

import ai.onnxruntime.OnnxTensor
import ai.onnxruntime.OrtEnvironment
import ai.onnxruntime.OrtSession
import java.nio.FloatBuffer
import kotlin.math.PI
import kotlin.math.sin

/**
 * Offline AI cleanup via ONNX Runtime (NNAPI when available, CPU fallback).
 *
 * Contract: a waveform-to-waveform model with input [1, 1, chunk] and output [1, 1, chunk]
 * (speech-enhancement / denoise / vocal-extraction exports). Set [chunk] to the model's fixed length.
 * Models that need an external STFT (e.g. raw MDX-Net / Demucs) must be exported with the STFT baked in,
 * or you must add the STFT/iSTFT stage in front of/after session.run().
 * Long files are processed in 50%-overlapped chunks and cross-faded (Hann overlap-add).
 */
class VocalIsolator(private val modelPath: String, private val chunk: Int = 48_000 * 4) {

    fun process(input: FloatArray, onProgress: (Float) -> Unit = {}): FloatArray {
        val env = OrtEnvironment.getEnvironment()
        val opts = OrtSession.SessionOptions().apply {
            setIntraOpNumThreads(4)
            try { addNnapi() } catch (_: Throwable) { /* CPU */ }
        }
        val out = FloatArray(input.size)
        val norm = FloatArray(input.size)
        val hop = chunk / 2
        val win = FloatArray(chunk) { val s = sin(PI * (it + 0.5) / chunk); (s * s).toFloat() }

        env.createSession(modelPath, opts).use { session ->
            val inName = session.inputNames.first()
            var pos = 0
            while (pos < input.size) {
                val frame = FloatArray(chunk)
                val len = minOf(chunk, input.size - pos)
                System.arraycopy(input, pos, frame, 0, len)

                OnnxTensor.createTensor(env, FloatBuffer.wrap(frame), longArrayOf(1, 1, chunk.toLong())).use { t ->
                    session.run(mapOf(inName to t)).use { res ->
                        val fb = (res[0] as OnnxTensor).floatBuffer
                        val y = FloatArray(chunk)
                        fb.get(y, 0, minOf(chunk, fb.remaining()))
                        for (i in 0 until len) { out[pos + i] += y[i] * win[i]; norm[pos + i] += win[i] }
                    }
                }
                pos += hop
                onProgress((pos.toFloat() / input.size).coerceIn(0f, 1f))
            }
        }
        for (i in out.indices) out[i] = if (norm[i] > 1e-4f) out[i] / norm[i] else 0f
        return out
    }
}
