# Studio DAW — Mobile Audio Workstation (Kotlin / Compose)

## Project structure
```
StudioDAW/
├── settings.gradle.kts / build.gradle.kts / gradle.properties
├── gradle/wrapper/gradle-wrapper.properties
└── app/
    ├── build.gradle.kts
    └── src/main/
        ├── AndroidManifest.xml
        └── java/com/studio/daw/
            ├── MainActivity.kt          permission gate + Compose host
            ├── StudioViewModel.kt       state, transport, export, AI job
            ├── audio/
            │   ├── AudioEngine.kt       AudioRecord -> AudioProcessor -> AudioTrack (low-latency thread), WAV capture
            │   ├── AudioProcessor.kt    full signal chain
            │   ├── Biquad.kt            HPF/LPF/shelves/peaking + 5-band parametric EQ
            │   ├── Dynamics.kt          compressor, noise gate, ducker, limiter
            │   ├── Effects.kt           Freeverb reverb, feedback delay
            │   ├── PitchCorrector.kt    YIN detection + scale snapping + pitch shifter
            │   ├── BackingTrack.kt      MediaCodec decoder for mp3/aac/wav/flac/ogg
            │   ├── SpectrumAnalyzer.kt  FFT bands + waveform for the visualizer
            │   ├── WavIO.kt             threaded WAV writer / reader
            │   └── FxParams.kt          all parameters + presets
            ├── ai/VocalIsolator.kt      ONNX Runtime chunked inference
            └── ui/ Theme.kt, Controls.kt (Knob/Fader/Meter), Visualizer.kt, StudioScreen.kt
```

## Build the APK
1. Install Android Studio (Koala or newer) with SDK 34.
2. File > Open > select the `StudioDAW` folder. Let Gradle sync (it downloads Gradle 8.9 automatically).
3. Quick install: connect a phone (USB debugging on) and press Run, or
   Build > Build Bundle(s) / APK(s) > Build APK(s).
4. Command line (after Android Studio created the wrapper, or with a local `gradle`):
   `./gradlew assembleDebug`  ->  `app/build/outputs/apk/debug/app-debug.apk`
5. Signed release APK: Build > Generate Signed Bundle / APK > APK, create a keystore, choose `release`.
   Or: `./gradlew assembleRelease` after adding a `signingConfigs` block.

## Notes
* Use wired headphones. Speaker monitoring will feed back; Bluetooth adds 150+ ms latency.
* Recordings go to `Music/StudioDAW/` (mix + dry vocal; AI output as `_ai.wav`).
* AI isolation needs your own `.onnx` model (waveform in/out, shape [1,1,N]); set `chunk` in VocalIsolator to match.
* Oboe upgrade: the DSP is pure Kotlin. For the lowest latency, port AudioProcessor to C++ and drive it from an Oboe callback.
